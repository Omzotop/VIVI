# Architettura di VIVI

## Cartelle
```
app/            Expo Router: _layout (font, apertura DB), (tabs)/ con le 5 schermate
src/theme/      token di design (colori lavanda/blu/bianco/grigio, spaziature, font Nunito)
src/components/ Text, Button, Card, TextField, Screen, EmptyState, ComingSoon
src/i18n/       i18next + locales/it.json (nuove lingue = nuovo file JSON)
src/db/         apertura SQLite, migrazioni append-only (PRAGMA user_version)
src/features/   una cartella per funzione: tasks/ (validazione, repository, hook)
src/sync/       regole pure di risoluzione dei conflitti
src/lib/        utilità (UUID, saluto)
tests/          test Jest della logica pura
```

## Offline-first
- Ogni lettura e scrittura passa dal database SQLite sul dispositivo: l'app non dipende dalla rete.
- Gli id sono UUID creati sul dispositivo, quindi si può creare offline senza collisioni.
- Modalità senza account: stesso database; alla registrazione (Fase 3) i dati vengono caricati nel cloud.

## Sincronizzazione senza perdite (progetto, implementazione in Fase 3)
Ogni record ha `updated_at`, `version`, `device_id`, `deleted_at` (cancellazione logica) e `dirty`.
1. **Push**: i record `dirty` vengono inviati al server; solo dopo la conferma `dirty` torna a 0.
2. **Pull**: si scaricano le modifiche successive all'ultimo cursore salvato.
3. **Conflitti** (`src/sync/resolve.ts`, testato): la modifica batte la cancellazione se successiva;
   tra due modifiche vince la più recente, con esito identico su ogni dispositivo; il perdente
   finisce in `sync_conflicts`, quindi nulla sparisce in silenzio.
4. Limite noto: il confronto usa gli orologi dei dispositivi. In Fase 3 il server assegnerà il
   timestamp autorevole per ridurre l'effetto di orologi sballati.
5. Le cancellazioni (tombstone) si eliminano fisicamente solo dopo che tutti i dispositivi le hanno ricevute.

## Gratuità
VIVI è gratuita e le funzioni essenziali non hanno limiti né paywall. Non c'è alcun codice di pagamento.
Nota di costo: la chat AI (Fase 4) usa un'API a pagamento. Per tenerla gratuita per gli utenti servirà un
limite di uso equo sul server, mai sulle funzioni essenziali (attività, spesa, calendario, promemoria, obiettivi).
Il limite e il budget sono una tua decisione da prendere prima della Fase 4.

## Sicurezza (Fasi 3-4)
Row Level Security su ogni tabella Supabase; chiave Claude solo nei secrets della Edge Function;
nell'app solo URL e anon key pubbliche; eliminazione account e dati a richiesta.
