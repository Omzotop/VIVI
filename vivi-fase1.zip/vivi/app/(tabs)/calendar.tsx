import { useTranslation } from 'react-i18next';
import { ComingSoon } from '@/components/ComingSoon';

export default function Screen_calendar() {
  const { t } = useTranslation();
  return <ComingSoon title={t('tabs.calendar')} message={t('soon.calendar')} />;
}
