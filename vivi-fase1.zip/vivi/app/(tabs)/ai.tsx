import { useTranslation } from 'react-i18next';
import { ComingSoon } from '@/components/ComingSoon';

export default function Screen_ai() {
  const { t } = useTranslation();
  return <ComingSoon title={t('tabs.ai')} message={t('soon.ai')} />;
}
