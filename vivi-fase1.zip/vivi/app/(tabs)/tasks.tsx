import { useState } from 'react';
import { Alert, Pressable, StyleSheet, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTranslation } from 'react-i18next';
import { Screen } from '@/components/Screen';
import { Text } from '@/components/Text';
import { Card } from '@/components/Card';
import { Button } from '@/components/Button';
import { TextField } from '@/components/TextField';
import { EmptyState } from '@/components/EmptyState';
import { getDb } from '@/db/database';
import { TaskFilter, createTask, deleteTask, setCompleted } from '@/features/tasks/repository';
import { useTasks } from '@/features/tasks/useTasks';
import { validateTask } from '@/features/tasks/validation';
import { colors, radius, spacing } from '@/theme/tokens';

export default function TasksScreen() {
  const { t } = useTranslation();
  const [filter, setFilter] = useState<TaskFilter>('open');
  const { tasks, error, refresh } = useTasks(filter);
  const [title, setTitle] = useState('');
  const [formError, setFormError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const add = async () => {
    const result = validateTask({ title });
    if (!result.ok) {
      setFormError(t(`tasks.errors.${result.error}`));
      return;
    }
    setSaving(true);
    try {
      await createTask(await getDb(), result.value);
      setTitle('');
      setFormError(null);
      await refresh();
    } catch {
      setFormError(t('tasks.errors.saveFailed'));
    } finally {
      setSaving(false);
    }
  };

  const toggle = async (id: string, done: boolean) => {
    await setCompleted(await getDb(), id, done);
    await refresh();
  };

  const remove = (id: string, name: string) =>
    Alert.alert(name, undefined, [
      { text: t('common.cancel'), style: 'cancel' },
      {
        text: t('common.delete'),
        style: 'destructive',
        onPress: async () => {
          await deleteTask(await getDb(), id);
          await refresh();
        },
      },
    ]);

  return (
    <Screen>
      <Text variant="title" accessibilityRole="header">
        {t('tasks.title')}
      </Text>

      <Card>
        <TextField
          label={t('tasks.titleLabel')}
          placeholder={t('tasks.titlePlaceholder')}
          value={title}
          onChangeText={(v) => {
            setTitle(v);
            if (formError) setFormError(null);
          }}
          onSubmitEditing={add}
          returnKeyType="done"
          error={formError}
          maxLength={200}
        />
        <Button label={t('tasks.add')} onPress={add} loading={saving} />
      </Card>

      <View style={styles.filters} accessibilityRole="tablist">
        {(['open', 'done'] as const).map((f) => (
          <Pressable
            key={f}
            accessibilityRole="tab"
            accessibilityState={{ selected: filter === f }}
            onPress={() => setFilter(f)}
            style={[styles.chip, filter === f && styles.chipActive]}
          >
            <Text style={filter === f ? styles.chipTextActive : undefined}>
              {t(f === 'open' ? 'tasks.filterOpen' : 'tasks.filterDone')}
            </Text>
          </Pressable>
        ))}
      </View>

      {error ? <Text style={{ color: colors.danger }}>{t('errors.dbTitle')}</Text> : null}

      {tasks.length === 0 && !error ? (
        <EmptyState
          title={t(filter === 'open' ? 'tasks.emptyOpen' : 'tasks.emptyDone')}
          hint={filter === 'open' ? t('tasks.emptyOpenHint') : undefined}
        />
      ) : null}

      {tasks.map((task) => {
        const done = task.completedAt !== null;
        return (
          <Card key={task.id} style={styles.row}>
            <Pressable
              accessibilityRole="checkbox"
              accessibilityState={{ checked: done }}
              accessibilityLabel={`${task.title}. ${t(done ? 'tasks.markOpen' : 'tasks.markDone')}`}
              onPress={() => toggle(task.id, !done)}
              hitSlop={8}
            >
              <Ionicons
                name={done ? 'checkmark-circle' : 'ellipse-outline'}
                size={28}
                color={done ? colors.success : colors.primary}
              />
            </Pressable>
            <Text style={[styles.rowTitle, done && styles.done]}>{task.title}</Text>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel={`${t('common.delete')}: ${task.title}`}
              onPress={() => remove(task.id, task.title)}
              hitSlop={8}
            >
              <Ionicons name="trash-outline" size={22} color={colors.textMuted} />
            </Pressable>
          </Card>
        );
      })}
    </Screen>
  );
}

const styles = StyleSheet.create({
  filters: { flexDirection: 'row', gap: spacing.sm },
  chip: {
    minHeight: 40,
    paddingHorizontal: spacing.md,
    justifyContent: 'center',
    borderRadius: radius.pill,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
  },
  chipActive: { backgroundColor: colors.primarySoft, borderColor: colors.primary },
  chipTextActive: { color: colors.primary },
  row: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  rowTitle: { flex: 1 },
  done: { textDecorationLine: 'line-through', color: colors.textMuted },
});
