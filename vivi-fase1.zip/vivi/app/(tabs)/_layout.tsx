import { Tabs } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useTranslation } from 'react-i18next';
import { colors, fonts } from '@/theme/tokens';

type IconName = React.ComponentProps<typeof Ionicons>['name'];

export default function TabsLayout() {
  const { t } = useTranslation();
  const tab = (title: string, icon: IconName) => ({
    title,
    tabBarIcon: ({ color, size }: { color: string; size: number }) => (
      <Ionicons name={icon} color={color} size={size} />
    ),
  });

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.textMuted,
        tabBarLabelStyle: { fontFamily: fonts.semibold, fontSize: 11 },
        tabBarStyle: { backgroundColor: colors.surface, borderTopColor: colors.border },
      }}
    >
      <Tabs.Screen name="index" options={tab(t('tabs.today'), 'sunny-outline')} />
      <Tabs.Screen name="tasks" options={tab(t('tabs.tasks'), 'checkmark-circle-outline')} />
      <Tabs.Screen name="shopping" options={tab(t('tabs.shopping'), 'cart-outline')} />
      <Tabs.Screen name="calendar" options={tab(t('tabs.calendar'), 'calendar-outline')} />
      <Tabs.Screen name="ai" options={tab(t('tabs.ai'), 'sparkles-outline')} />
    </Tabs>
  );
}
