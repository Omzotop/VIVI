import { useCallback, useState } from 'react';
import { useFocusEffect, useRouter } from 'expo-router';
import { useTranslation } from 'react-i18next';
import { Screen } from '@/components/Screen';
import { Text } from '@/components/Text';
import { Card } from '@/components/Card';
import { Button } from '@/components/Button';
import { getDb } from '@/db/database';
import { Task, countOpen, listTasks } from '@/features/tasks/repository';
import { greetingKey } from '@/lib/greeting';

export default function HomeScreen() {
  const { t, i18n } = useTranslation();
  const router = useRouter();
  const [open, setOpen] = useState(0);
  const [next, setNext] = useState<Task[]>([]);

  useFocusEffect(
    useCallback(() => {
      let active = true;
      (async () => {
        const db = await getDb();
        const [n, tasks] = await Promise.all([countOpen(db), listTasks(db, 'open', 3)]);
        if (active) {
          setOpen(n);
          setNext(tasks);
        }
      })().catch(() => undefined);
      return () => {
        active = false;
      };
    }, []),
  );

  const today = new Date().toLocaleDateString(i18n.language, {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
  });
  const summary =
    open === 0 ? t('home.summaryNone') : open === 1 ? t('home.summaryOne') : t('home.summaryMany', { count: open });

  return (
    <Screen>
      <Text variant="caption" muted>
        {today}
      </Text>
      <Text variant="title" accessibilityRole="header">
        {t(greetingKey())}
      </Text>
      <Card>
        <Text variant="heading">{summary}</Text>
        {next.length > 0 ? <Text muted>{t('home.upcoming')}</Text> : null}
        {next.map((task) => (
          <Text key={task.id}>• {task.title}</Text>
        ))}
      </Card>
      <Button label={t('home.newTask')} onPress={() => router.push('/tasks')} />
    </Screen>
  );
}
