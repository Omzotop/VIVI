import { Text as RNText, TextProps, StyleSheet } from 'react-native';
import { colors, fonts } from '@/theme/tokens';

type Variant = 'title' | 'heading' | 'body' | 'caption';
type Props = TextProps & { variant?: Variant; muted?: boolean };

export function Text({ variant = 'body', muted, style, ...rest }: Props) {
  return <RNText {...rest} style={[styles[variant], muted && styles.muted, style]} />;
}

const styles = StyleSheet.create({
  title: { fontFamily: fonts.bold, fontSize: 28, lineHeight: 34, color: colors.text },
  heading: { fontFamily: fonts.semibold, fontSize: 19, lineHeight: 26, color: colors.text },
  body: { fontFamily: fonts.regular, fontSize: 16, lineHeight: 24, color: colors.text },
  caption: { fontFamily: fonts.regular, fontSize: 13, lineHeight: 18, color: colors.text },
  muted: { color: colors.textMuted },
});
