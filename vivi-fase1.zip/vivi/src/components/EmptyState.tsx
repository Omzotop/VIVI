import { StyleSheet, View } from 'react-native';
import { Text } from './Text';
import { spacing } from '@/theme/tokens';

export function EmptyState({ title, hint }: { title: string; hint?: string }) {
  return (
    <View style={styles.box}>
      <Text variant="heading" style={styles.center}>
        {title}
      </Text>
      {hint ? (
        <Text muted style={styles.center}>
          {hint}
        </Text>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  box: { padding: spacing.lg, gap: spacing.sm, alignItems: 'center' },
  center: { textAlign: 'center' },
});
