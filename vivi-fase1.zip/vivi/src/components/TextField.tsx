import { StyleSheet, TextInput, TextInputProps, View } from 'react-native';
import { Text } from './Text';
import { colors, fonts, radius, spacing } from '@/theme/tokens';

type Props = TextInputProps & { label: string; error?: string | null };

export function TextField({ label, error, style, ...rest }: Props) {
  return (
    <View style={{ gap: spacing.xs }}>
      <Text variant="caption" muted>
        {label}
      </Text>
      <TextInput
        accessibilityLabel={label}
        placeholderTextColor={colors.textMuted}
        {...rest}
        style={[styles.input, error ? styles.errorBorder : null, style]}
      />
      {error ? (
        <Text variant="caption" style={{ color: colors.danger }} accessibilityLiveRegion="polite">
          {error}
        </Text>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  input: {
    minHeight: 48,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.sm,
    backgroundColor: colors.surface,
    paddingHorizontal: spacing.md,
    fontFamily: fonts.regular,
    fontSize: 16,
    color: colors.text,
  },
  errorBorder: { borderColor: colors.danger },
});
