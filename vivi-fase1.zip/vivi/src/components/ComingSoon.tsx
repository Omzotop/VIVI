import { useTranslation } from 'react-i18next';
import { Screen } from './Screen';
import { Text } from './Text';
import { Card } from './Card';

export function ComingSoon({ title, message }: { title: string; message: string }) {
  const { t } = useTranslation();
  return (
    <Screen>
      <Text variant="title">{title}</Text>
      <Card>
        <Text variant="heading">{t('soon.title')}</Text>
        <Text muted>{message}</Text>
      </Card>
    </Screen>
  );
}
