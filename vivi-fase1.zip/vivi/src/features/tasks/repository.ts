import { Db, deviceId } from '@/db/database';
import { newId } from '@/lib/id';
import { ValidTask } from './validation';

export type Task = {
  id: string;
  title: string;
  notes: string;
  dueAt: number | null;
  priority: 0 | 1 | 2;
  category: string | null;
  completedAt: number | null;
  createdAt: number;
  updatedAt: number;
};

type Row = {
  id: string;
  title: string;
  notes: string;
  due_at: number | null;
  priority: 0 | 1 | 2;
  category: string | null;
  completed_at: number | null;
  created_at: number;
  updated_at: number;
};

const COLS = 'id, title, notes, due_at, priority, category, completed_at, created_at, updated_at';

const toTask = (r: Row): Task => ({
  id: r.id,
  title: r.title,
  notes: r.notes,
  dueAt: r.due_at,
  priority: r.priority,
  category: r.category,
  completedAt: r.completed_at,
  createdAt: r.created_at,
  updatedAt: r.updated_at,
});

export type TaskFilter = 'open' | 'done';

export async function listTasks(db: Db, filter: TaskFilter, limit = 200): Promise<Task[]> {
  const where = filter === 'open' ? 'completed_at IS NULL' : 'completed_at IS NOT NULL';
  const order =
    filter === 'open'
      ? 'priority DESC, due_at IS NULL, due_at ASC, created_at DESC'
      : 'completed_at DESC';
  const rows = await db.getAllAsync<Row>(
    `SELECT ${COLS} FROM tasks WHERE deleted_at IS NULL AND ${where} ORDER BY ${order} LIMIT ?`,
    limit,
  );
  return rows.map(toTask);
}

export async function countOpen(db: Db): Promise<number> {
  const r = await db.getFirstAsync<{ n: number }>(
    'SELECT COUNT(*) AS n FROM tasks WHERE deleted_at IS NULL AND completed_at IS NULL',
  );
  return r?.n ?? 0;
}

export async function createTask(db: Db, v: ValidTask): Promise<string> {
  const id = newId();
  const now = Date.now();
  await db.runAsync(
    `INSERT INTO tasks (id, title, notes, due_at, priority, category, created_at, updated_at, device_id, version, dirty)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 1)`,
    id, v.title, v.notes, v.dueAt, v.priority, v.category, now, now, deviceId(),
  );
  return id;
}

export async function setCompleted(db: Db, id: string, done: boolean): Promise<void> {
  const now = Date.now();
  await db.runAsync(
    `UPDATE tasks SET completed_at = ?, updated_at = ?, version = version + 1, device_id = ?, dirty = 1
     WHERE id = ? AND deleted_at IS NULL`,
    done ? now : null, now, deviceId(), id,
  );
}

/** Cancellazione logica: il record resta come "tombstone" finché non è sincronizzato. */
export async function deleteTask(db: Db, id: string): Promise<void> {
  const now = Date.now();
  await db.runAsync(
    `UPDATE tasks SET deleted_at = ?, updated_at = ?, version = version + 1, device_id = ?, dirty = 1
     WHERE id = ? AND deleted_at IS NULL`,
    now, now, deviceId(), id,
  );
}
