export type TaskInput = {
  title: string;
  notes?: string;
  dueAt?: number | null;
  priority?: 0 | 1 | 2;
  category?: string | null;
};

export type TaskErrorCode = 'titleRequired' | 'titleTooLong' | 'notesTooLong';

export type ValidTask = {
  title: string;
  notes: string;
  dueAt: number | null;
  priority: 0 | 1 | 2;
  category: string | null;
};

export type ValidationResult = { ok: true; value: ValidTask } | { ok: false; error: TaskErrorCode };

export const TITLE_MAX = 120;
export const NOTES_MAX = 2000;

export function validateTask(input: TaskInput): ValidationResult {
  const title = input.title.trim();
  const notes = (input.notes ?? '').trim();
  if (title.length === 0) return { ok: false, error: 'titleRequired' };
  if (title.length > TITLE_MAX) return { ok: false, error: 'titleTooLong' };
  if (notes.length > NOTES_MAX) return { ok: false, error: 'notesTooLong' };
  const category = input.category?.trim() || null;
  return {
    ok: true,
    value: { title, notes, dueAt: input.dueAt ?? null, priority: input.priority ?? 0, category },
  };
}
