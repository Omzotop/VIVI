import { useCallback, useState } from 'react';
import { useFocusEffect } from 'expo-router';
import { getDb } from '@/db/database';
import { Task, TaskFilter, listTasks } from './repository';

export function useTasks(filter: TaskFilter) {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  const refresh = useCallback(async () => {
    try {
      const db = await getDb();
      setTasks(await listTasks(db, filter));
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e : new Error(String(e)));
    } finally {
      setLoading(false);
    }
  }, [filter]);

  useFocusEffect(
    useCallback(() => {
      void refresh();
    }, [refresh]),
  );

  return { tasks, loading, error, refresh };
}
