export const colors = {
  primary: '#6D5FD0', // lavanda intenso: testo bianco AA
  primarySoft: '#E9E5FA', // lavanda chiaro
  accent: '#5B8DEF', // blu delicato
  accentSoft: '#E3EDFC',
  background: '#F6F5FB',
  surface: '#FFFFFF',
  border: '#E4E2EE', // grigio chiaro
  text: '#1F1B3A',
  textMuted: '#5F5C75',
  danger: '#C0392B',
  success: '#2E8B6A',
} as const;

export const spacing = { xs: 4, sm: 8, md: 16, lg: 24, xl: 32 } as const;
export const radius = { sm: 10, md: 16, pill: 999 } as const;

export const fonts = {
  regular: 'Nunito_400Regular',
  semibold: 'Nunito_600SemiBold',
  bold: 'Nunito_700Bold',
} as const;
