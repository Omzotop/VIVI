/**
 * Migrazioni append-only: non modificare mai una migrazione già rilasciata,
 * aggiungine una nuova in fondo. La versione corrente vive in PRAGMA user_version.
 *
 * Colonne di sincronizzazione presenti su ogni tabella di dominio:
 *  - id          UUID generato sul dispositivo
 *  - updated_at  ms epoch dell'ultima modifica
 *  - deleted_at  "tombstone": le cancellazioni sono logiche, così si possono sincronizzare
 *  - version     contatore incrementato a ogni modifica locale
 *  - device_id   dispositivo che ha fatto l'ultima modifica
 *  - dirty       1 = modifica non ancora inviata al server
 */
export const MIGRATIONS: string[] = [
  `
  CREATE TABLE meta (
    key   TEXT PRIMARY KEY NOT NULL,
    value TEXT NOT NULL
  );

  CREATE TABLE tasks (
    id           TEXT PRIMARY KEY NOT NULL,
    title        TEXT NOT NULL,
    notes        TEXT NOT NULL DEFAULT '',
    due_at       INTEGER,
    priority     INTEGER NOT NULL DEFAULT 0 CHECK (priority BETWEEN 0 AND 2),
    category     TEXT,
    completed_at INTEGER,
    created_at   INTEGER NOT NULL,
    updated_at   INTEGER NOT NULL,
    deleted_at   INTEGER,
    version      INTEGER NOT NULL DEFAULT 1,
    device_id    TEXT NOT NULL,
    dirty        INTEGER NOT NULL DEFAULT 1
  );
  CREATE INDEX idx_tasks_active ON tasks (deleted_at, completed_at, due_at);
  CREATE INDEX idx_tasks_dirty  ON tasks (dirty) WHERE dirty = 1;

  -- Archivio dei record "perdenti" in un conflitto: nulla viene buttato via.
  CREATE TABLE sync_conflicts (
    id          TEXT PRIMARY KEY NOT NULL,
    table_name  TEXT NOT NULL,
    record_id   TEXT NOT NULL,
    payload     TEXT NOT NULL,
    created_at  INTEGER NOT NULL
  );
  `,
];
