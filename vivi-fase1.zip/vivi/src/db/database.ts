import * as SQLite from 'expo-sqlite';
import { MIGRATIONS } from './migrations';
import { newId } from '@/lib/id';

export type Db = SQLite.SQLiteDatabase;

let dbPromise: Promise<Db> | null = null;

/** Apre (una sola volta) il database locale e applica le migrazioni. Funziona offline. */
export function getDb(): Promise<Db> {
  if (!dbPromise) {
    dbPromise = open().catch((e) => {
      dbPromise = null; // consente di riprovare
      throw e;
    });
  }
  return dbPromise;
}

async function open(): Promise<Db> {
  const db = await SQLite.openDatabaseAsync('vivi.db');
  await db.execAsync('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON;');
  await migrate(db);
  await ensureDeviceId(db);
  return db;
}

export async function migrate(db: Db): Promise<void> {
  const row = await db.getFirstAsync<{ user_version: number }>('PRAGMA user_version');
  const current = row?.user_version ?? 0;
  for (let i = current; i < MIGRATIONS.length; i++) {
    await db.withTransactionAsync(async () => {
      await db.execAsync(MIGRATIONS[i]!);
      await db.execAsync(`PRAGMA user_version = ${i + 1}`);
    });
  }
}

let cachedDeviceId: string | null = null;

async function ensureDeviceId(db: Db): Promise<void> {
  const row = await db.getFirstAsync<{ value: string }>("SELECT value FROM meta WHERE key = 'device_id'");
  if (row) {
    cachedDeviceId = row.value;
    return;
  }
  const id = newId();
  await db.runAsync("INSERT INTO meta (key, value) VALUES ('device_id', ?)", id);
  cachedDeviceId = id;
}

export function deviceId(): string {
  if (!cachedDeviceId) throw new Error('Database non inizializzato');
  return cachedDeviceId;
}
