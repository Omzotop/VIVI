import { randomUUID } from 'expo-crypto';

/** UUID v4 generato sul dispositivo: permette di creare record offline senza collisioni tra dispositivi. */
export const newId = (): string => randomUUID();
