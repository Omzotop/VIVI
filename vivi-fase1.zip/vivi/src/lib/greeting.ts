export type GreetingKey = 'greeting.morning' | 'greeting.afternoon' | 'greeting.evening';

export function greetingKey(date: Date = new Date()): GreetingKey {
  const h = date.getHours();
  if (h >= 5 && h < 13) return 'greeting.morning';
  if (h >= 13 && h < 18) return 'greeting.afternoon';
  return 'greeting.evening';
}
