/**
 * Regole di risoluzione dei conflitti (puro, testabile, senza dipendenze).
 *
 * Obiettivo: nessuna perdita silenziosa di dati.
 *  1. Se il locale non ha modifiche in sospeso (dirty = false) vince il remoto.
 *  2. Modifica vs cancellazione: vince la modifica se è successiva alla cancellazione.
 *  3. Modifica vs modifica: vince updatedAt più recente. A parità vince il deviceId
 *     lessicograficamente maggiore, così ogni dispositivo arriva allo stesso esito.
 *  4. Il record perdente, se conteneva modifiche reali, va archiviato in sync_conflicts.
 */
export type SyncMeta = {
  id: string;
  updatedAt: number;
  deletedAt: number | null;
  deviceId: string;
};

export type LocalSyncMeta = SyncMeta & { dirty: boolean };

export type Resolution = {
  winner: 'local' | 'remote';
  /** true se il perdente va conservato in archivio */
  archiveLoser: boolean;
};

export function resolveConflict(local: LocalSyncMeta, remote: SyncMeta): Resolution {
  if (!local.dirty) return { winner: 'remote', archiveLoser: false };

  const localDeleted = local.deletedAt !== null;
  const remoteDeleted = remote.deletedAt !== null;

  if (localDeleted !== remoteDeleted) {
    const deleted = localDeleted ? local : remote;
    const edited = localDeleted ? remote : local;
    const editWins = edited.updatedAt > (deleted.deletedAt ?? 0);
    const editedIsLocal = !localDeleted;
    const winner: 'local' | 'remote' = editWins === editedIsLocal ? 'local' : 'remote';
    return { winner, archiveLoser: true };
  }

  if (local.updatedAt !== remote.updatedAt) {
    return { winner: local.updatedAt > remote.updatedAt ? 'local' : 'remote', archiveLoser: true };
  }
  if (local.deviceId === remote.deviceId) return { winner: 'remote', archiveLoser: false };
  return { winner: local.deviceId > remote.deviceId ? 'local' : 'remote', archiveLoser: true };
}
