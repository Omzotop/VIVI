import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import { getLocales } from 'expo-localization';
import it from './locales/it.json';

// Per aggiungere una lingua: crea locales/<codice>.json e registralo qui sotto.
const resources = { it: { translation: it } };

const device = getLocales()[0]?.languageCode ?? 'it';
const lng = device in resources ? device : 'it';

void i18n.use(initReactI18next).init({
  resources,
  lng,
  fallbackLng: 'it',
  interpolation: { escapeValue: false },
});

export default i18n;
