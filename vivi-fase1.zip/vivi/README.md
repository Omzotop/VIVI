# VIVI — assistente personale (Fase 1)

App mobile iOS/Android con Expo, React Native, TypeScript ed Expo Router. Lingua iniziale: italiano.

## Stato del progetto (onesto)

| Area | Stato |
|---|---|
| Struttura, design system, navigazione a 5 tab | Fase 1: fatto |
| Database locale SQLite con migrazioni, funziona offline | Fase 1: fatto |
| Attività: crea, completa, elimina, filtra (da fare/completate) | Fase 1: funzionante |
| Attività: scadenze, priorità, categorie, ricorrenze, ricerca | Fase 2 (il database ha già le colonne) |
| Spesa, Calendario, Promemoria, Obiettivi | Fase 2 |
| Backend Supabase, account, sincronizzazione | Fase 3 (regole di conflitto già scritte e testate) |
| VIVI AI (Claude via Edge Function) | Fase 4 |
| Test automatici | Parziali: logica pura coperta; test dei componenti in Fase 5 |

Le schermate Spesa, Calendario e VIVI AI mostrano un avviso "In arrivo": non sono funzioni finte.

## Requisiti
Node 20+ e l'app Expo Go aggiornata sul telefono (stesso Wi-Fi del computer).

## Avvio
```bash
npm install
npx expo install --fix   # allinea le versioni dei pacchetti all'SDK Expo in uso
npx expo start
```
Scansiona il QR con Expo Go (Android) o con la Fotocamera (iOS).

> Le versioni in `package.json` sono impostate per Expo SDK 54 e **non sono state installate né avviate**
> dove ho preparato il progetto (senza accesso alla rete). Se `npm install` segnala conflitti, `npx expo install --fix` li risolve.

## Test
```bash
npm run typecheck
npm test
```

## Prova guidata (Expo Go)
1. All'apertura vedi "Oggi" con il saluto e "Nessuna attività da fare".
2. Tab **Attività**: scrivi un titolo e premi *Aggiungi attività*; con campo vuoto compare l'errore.
3. Tocca il cerchio per completare: l'attività passa in *Completate*.
4. Attiva la modalità aereo, aggiungi un'attività, chiudi e riapri l'app: i dati restano (tutto è locale).
5. Torna su "Oggi": il conteggio e l'elenco sono aggiornati.

## Identificativi da cambiare prima della pubblicazione
`app.json`: `ios.bundleIdentifier` e `android.package` sono segnaposto (`app.vivi.mobile`). Icona e splash vanno aggiunti.
Account Apple Developer / Google Play, certificati e approvazioni **non sono inclusi né stati eseguiti**.

## Documentazione
Vedi `docs/ARCHITECTURE.md`.
