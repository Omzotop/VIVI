import { resolveConflict, LocalSyncMeta, SyncMeta } from '../src/sync/resolve';

const local = (o: Partial<LocalSyncMeta> = {}): LocalSyncMeta => ({
  id: 'x', updatedAt: 100, deletedAt: null, deviceId: 'A', dirty: true, ...o,
});
const remote = (o: Partial<SyncMeta> = {}): SyncMeta => ({
  id: 'x', updatedAt: 100, deletedAt: null, deviceId: 'B', ...o,
});

describe('resolveConflict', () => {
  it('senza modifiche locali in sospeso vince il remoto', () => {
    expect(resolveConflict(local({ dirty: false }), remote())).toEqual({ winner: 'remote', archiveLoser: false });
  });
  it('modifica vs modifica: vince la più recente e il perdente è archiviato', () => {
    expect(resolveConflict(local({ updatedAt: 200 }), remote({ updatedAt: 150 }))).toEqual({ winner: 'local', archiveLoser: true });
    expect(resolveConflict(local({ updatedAt: 100 }), remote({ updatedAt: 150 }))).toEqual({ winner: 'remote', archiveLoser: true });
  });
  it('a parità di tempo l\'esito è deterministico su entrambi i dispositivi', () => {
    const a = resolveConflict(local({ deviceId: 'A' }), remote({ deviceId: 'B' }));
    const b = resolveConflict(local({ deviceId: 'B' }), remote({ deviceId: 'A' }));
    expect(a.winner).toBe('remote'); // vince B
    expect(b.winner).toBe('local'); // vince B
  });
  it('modifica successiva a una cancellazione: la modifica vince (nessuna perdita)', () => {
    expect(resolveConflict(local({ updatedAt: 300 }), remote({ deletedAt: 200, updatedAt: 200 }))).toEqual({ winner: 'local', archiveLoser: true });
    expect(resolveConflict(local({ deletedAt: 200, updatedAt: 200 }), remote({ updatedAt: 300 }))).toEqual({ winner: 'remote', archiveLoser: true });
  });
  it('cancellazione successiva alla modifica: vince la cancellazione, la modifica è archiviata', () => {
    expect(resolveConflict(local({ updatedAt: 100 }), remote({ deletedAt: 200, updatedAt: 200 }))).toEqual({ winner: 'remote', archiveLoser: true });
  });
});
