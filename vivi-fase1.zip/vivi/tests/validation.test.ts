import { validateTask, TITLE_MAX, NOTES_MAX } from '../src/features/tasks/validation';

describe('validateTask', () => {
  it('rifiuta un titolo vuoto o di soli spazi', () => {
    expect(validateTask({ title: '' })).toEqual({ ok: false, error: 'titleRequired' });
    expect(validateTask({ title: '   ' })).toEqual({ ok: false, error: 'titleRequired' });
  });
  it('rifiuta titolo e note troppo lunghi', () => {
    expect(validateTask({ title: 'a'.repeat(TITLE_MAX + 1) })).toEqual({ ok: false, error: 'titleTooLong' });
    expect(validateTask({ title: 'ok', notes: 'n'.repeat(NOTES_MAX + 1) })).toEqual({ ok: false, error: 'notesTooLong' });
  });
  it('normalizza i valori validi', () => {
    const r = validateTask({ title: '  Chiamare Anna ', category: '  ' });
    expect(r).toEqual({
      ok: true,
      value: { title: 'Chiamare Anna', notes: '', dueAt: null, priority: 0, category: null },
    });
  });
});
