import { greetingKey } from '../src/lib/greeting';

const at = (h: number) => new Date(2026, 0, 1, h, 0, 0);

describe('greetingKey', () => {
  it('sceglie il saluto in base all\'ora', () => {
    expect(greetingKey(at(8))).toBe('greeting.morning');
    expect(greetingKey(at(15))).toBe('greeting.afternoon');
    expect(greetingKey(at(21))).toBe('greeting.evening');
    expect(greetingKey(at(2))).toBe('greeting.evening');
  });
});
